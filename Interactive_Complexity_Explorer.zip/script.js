const pages=[...document.querySelectorAll(".page")];
const navs=[...document.querySelectorAll(".nav")];
const titles={dashboard:"Interactive Complexity Explorer",concepts:"Complexity Classes",algorithms:"Algorithm Lab",visualizer:"Graph Visualizer",problems:"Problem Lab",quiz:"Knowledge Check",performance:"Performance Analysis"};

function showPage(id){
  pages.forEach(p=>p.classList.toggle("active-page",p.id===id));
  navs.forEach(n=>n.classList.toggle("active",n.dataset.page===id));
  document.getElementById("pageTitle").textContent=titles[id];
  window.scrollTo({top:0,behavior:"smooth"});
}
navs.forEach(n=>n.onclick=()=>showPage(n.dataset.page));

function selectConcept(el,name,desc,examples){
  document.querySelectorAll(".concept").forEach(x=>x.classList.remove("selected"));
  el.classList.add("selected");
  document.getElementById("conceptInfo").innerHTML=`<span class="pill">SELECTED CONCEPT</span><h3>${name}</h3><p>${desc}</p><strong>${examples}</strong>`;
}

function renderAlgoHelp(){
  const a=document.getElementById("algoSelect").value;
  const label=document.getElementById("inputLabel"), input=document.getElementById("algoInput"), help=document.getElementById("algoHelp");
  if(a==="knapsack"){label.textContent="Capacity";input.value="10";help.innerHTML="<p class='card' style='padding:10px;margin:8px 0;font-size:12px'>Uses DP. Demo items: weights [2,5,7,3], values [20,30,45,25].</p>";}
  if(a==="tsp"){label.textContent="Number of Cities";input.value="4";help.innerHTML="<p class='card' style='padding:10px;margin:8px 0;font-size:12px'>Runs brute-force TSP on a small matrix. Complexity grows factorially.</p>";}
  if(a==="vertex"){label.textContent="Graph";input.value="0-1,0-2,1-3,2-3";help.innerHTML="<p class='card' style='padding:10px;margin:8px 0;font-size:12px'>Greedy approximation selects both endpoints of an uncovered edge.</p>";}
}
renderAlgoHelp();

function knapsack(cap){
  const w=[2,5,7,3], v=[20,30,45,25], dp=Array.from({length:w.length+1},()=>Array(cap+1).fill(0));
  for(let i=1;i<=w.length;i++) for(let c=1;c<=cap;c++) dp[i][c]=w[i-1]<=c?Math.max(v[i-1]+dp[i-1][c-w[i-1]],dp[i-1][c]):dp[i-1][c];
  return dp[w.length][cap];
}
function tsp(n){
  const g=[[0,10,15,20,25],[10,0,35,25,17],[15,35,0,30,28],[20,25,30,0,12],[25,17,28,12,0]];
  n=Math.min(n,5); let best=Infinity,bestPath="";
  const used=Array(n).fill(false); used[0]=true;
  function go(cur,count,cost,path){
    if(count===n){let total=cost+g[cur][0];if(total<best){best=total;bestPath=path+" → A"}return;}
    for(let x=1;x<n;x++)if(!used[x]){used[x]=true;go(x,count+1,cost+g[cur][x],path+" → "+String.fromCharCode(65+x));used[x]=false;}
  }
  go(0,1,0,"A");return {best,bestPath};
}
function vertex(edges){
  let rem=edges.map(e=>e.split("-").map(Number)), cover=[];
  while(rem.length){const [u,v]=rem[0];cover.push(u,v);rem=rem.filter(e=>!e.includes(u)&&!e.includes(v));}
  return [...new Set(cover)];
}
function runAlgorithm(){
  const a=document.getElementById("algoSelect").value, val=document.getElementById("algoInput").value.trim(), out=document.getElementById("algoOutput");
  const t=performance.now();
  let result="";
  if(a==="knapsack"){let cap=Math.max(0,parseInt(val)||10);let ans=knapsack(cap);result=`Algorithm: 0/1 Knapsack\nTechnique: Dynamic Programming\nCapacity: ${cap}\nMaximum Value: ${ans}\nTime Complexity: O(n × W)`;}
  else if(a==="tsp"){let n=Math.max(2,Math.min(5,parseInt(val)||4));let r=tsp(n);result=`Algorithm: TSP Brute Force\nCities: ${n}\nBest Route: ${r.bestPath}\nMinimum Cost: ${r.best}\nTime Complexity: O(n!)\n\nNote: Demo limited to 5 cities for browser responsiveness.`;}
  else {let edges=val.split(",").map(x=>x.trim()).filter(Boolean);let c=vertex(edges);result=`Algorithm: Vertex Cover Approximation\nEdges: ${edges.join(", ")}\nApproximate Cover: { ${c.join(", ")} }\nTechnique: Greedy approximation\nResult: Valid cover for the selected edges.`;}
  const elapsed=performance.now()-t;
  out.textContent=result+`\nMeasured browser execution: ${elapsed.toFixed(3)} ms`;
  document.getElementById("algoBadge").textContent="COMPLETED";
}

function parseEdges(){
  return document.getElementById("edgesInput").value.split(",").map(s=>s.trim()).filter(Boolean).map(s=>s.split("-").map(Number)).filter(e=>e.length===2&&!e.some(Number.isNaN));
}
function runGraph(type){
  const edges=parseEdges(), adj={};
  edges.forEach(([u,v])=>{(adj[u]??=[]).push(v);(adj[v]??=[]).push(u);});
  const start=parseInt(document.getElementById("startNode").value)||0, seen=new Set(), order=[];
  if(type==="BFS"){const q=[start];seen.add(start);while(q.length){const u=q.shift();order.push(u);(adj[u]||[]).forEach(v=>{if(!seen.has(v)){seen.add(v);q.push(v)}})}}
  else{function dfs(u){seen.add(u);order.push(u);(adj[u]||[]).forEach(v=>{if(!seen.has(v))dfs(v)})}dfs(start)}
  document.getElementById("graphTrace").textContent=`${type} traversal: ${order.join(" → ")}`;
  drawGraph(edges,order);
}
function drawGraph(edges,order){
  const c=document.getElementById("graphCanvas"),ctx=c.getContext("2d"), nodes=[...new Set(edges.flat())].sort((a,b)=>a-b), pos={};
  const cx=c.width/2,cy=c.height/2,r=Math.min(145,100+nodes.length*5);
  nodes.forEach((n,i)=>{let ang=(2*Math.PI*i/nodes.length)-Math.PI/2;pos[n]={x:cx+r*Math.cos(ang),y:cy+r*Math.sin(ang)}});
  ctx.clearRect(0,0,c.width,c.height);ctx.strokeStyle="#ccd5e3";ctx.lineWidth=2;
  edges.forEach(([u,v])=>{ctx.beginPath();ctx.moveTo(pos[u].x,pos[u].y);ctx.lineTo(pos[v].x,pos[v].y);ctx.stroke()});
  nodes.forEach(n=>{ctx.beginPath();ctx.arc(pos[n].x,pos[n].y,23,0,Math.PI*2);ctx.fillStyle=order.indexOf(n)>=0?"#587eff":"#e8edf5";ctx.fill();ctx.fillStyle=order.indexOf(n)>=0?"#fff":"#172033";ctx.font="bold 14px Arial";ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillText(n,pos[n].x,pos[n].y)});
}
runGraph("BFS");

function evaluateProblem(){
  const type=document.getElementById("problemType").value,data=document.getElementById("problemData").value.trim(),box=document.getElementById("evaluation");
  if(!data){box.textContent="Please enter a problem instance first.";box.style.background="#fff0f0";box.style.color="#a53b3b";box.classList.add("show");return;}
  box.style.background="#edf8f3";box.style.color="#187b58";box.textContent=`✓ ${type} instance received successfully. Input format is valid for the demo evaluator. You can connect this module to a Java backend for full exact evaluation.`;box.classList.add("show");
}

const questions=[
 ["Which class contains problems solvable in polynomial time?","P",["P","NP","NP-Hard","NP-Complete"]],
 ["Which technique is used in the Knapsack implementation?","Dynamic Programming",["BFS","Dynamic Programming","DFS","Sorting"]],
 ["Which problem is commonly used as an NP-Complete example?","Hamiltonian Cycle",["Binary Search","Hamiltonian Cycle","Merge Sort","BFS"]],
 ["Which traversal uses a queue?","BFS",["DFS","BFS","Backtracking","Greedy"]]
];
function renderQuiz(){document.getElementById("quizBox").innerHTML=questions.map((q,i)=>`<div class="quiz-q"><h4>${i+1}. ${q[0]}</h4>${q[2].map(o=>`<label><input type="radio" name="q${i}" value="${o}"> ${o}</label>`).join("")}</div>`).join("")}
function submitQuiz(){let score=0;questions.forEach((q,i)=>{const a=document.querySelector(`input[name=q${i}]:checked`);if(a&&a.value===q[1])score++});document.getElementById("scoreBadge").textContent=`${score} / ${questions.length}`;const r=document.getElementById("quizResult");r.textContent=`Your score: ${score}/${questions.length}. ${score===questions.length?"Excellent — all answers are correct!":"Review the concepts and try again."}`;r.classList.add("show")}
renderQuiz();
