# Interactive Complexity Explorer

A browser-based DSA-3 project prototype for learning P, NP, NP-Complete and NP-Hard concepts.

## Run
1. Extract the folder.
2. Open `index.html` in Chrome/Edge.
3. No installation is required for the frontend demo.

## Included
- Dashboard
- P / NP / NP-Complete / NP-Hard concept cards
- Knapsack dynamic programming
- TSP brute-force demo
- Vertex Cover approximation
- BFS / DFS graph visualizer
- User-generated problem evaluation interface
- Quiz with automatic scoring
- Complexity/performance table

## Java integration
The current package is a functional frontend prototype. The algorithm logic is implemented in JavaScript so it runs immediately in a browser. The same algorithms can be moved to a Java backend (Spring Boot/Servlet) if your faculty requires Java as the implementation language.
